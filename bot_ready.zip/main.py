import asyncio
import html
import json
import logging
import os
import sys
from pathlib import Path

from aiogram import Bot, Dispatcher, types
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandObject

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    stream=sys.stdout,
)
log = logging.getLogger("giftbot")

# ---------- Конфиг (только через переменные окружения) ----------
BOT_TOKEN = os.getenv("BOT_TOKEN") or os.getenv("TELEGRAM_BOT_TOKEN")
if not BOT_TOKEN or ":" not in BOT_TOKEN:
    log.error("Не задан BOT_TOKEN (переменная окружения). Выход.")
    sys.exit(1)

CHECK_INTERVAL = int(os.getenv("CHECK_INTERVAL", "180"))  # секунд
DATA_FILE = Path(os.getenv("DATA_FILE", "tracked.json"))
PORT = os.getenv("PORT")  # если хостинг требует открытый порт — поднимем health-check

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

# ---------- Хранилище отслеживаемых подарков ----------
tracked: dict[int, list[str]] = {}


def load_tracked() -> None:
    try:
        if DATA_FILE.exists():
            raw = json.loads(DATA_FILE.read_text(encoding="utf-8"))
            tracked.update({int(k): v for k, v in raw.items()})
            log.info("Загружено отслеживание: %d пользователей", len(tracked))
    except Exception:
        log.exception("Не удалось прочитать %s", DATA_FILE)


def save_tracked() -> None:
    try:
        DATA_FILE.write_text(
            json.dumps(tracked, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    except Exception:
        log.exception("Не удалось сохранить %s", DATA_FILE)


# ---------- Ленивая загрузка TelegramGifts ----------
gifts = None
gifts_error: str | None = None
_gifts_lock = asyncio.Lock()


def _init_gifts():
    from TelegramGifts import TelegramGifts

    try:
        return TelegramGifts(cache_mode="http", asset_mode="lazy")
    except TypeError:
        # если в установленной версии библиотеки другие параметры
        return TelegramGifts()


async def ensure_gifts() -> bool:
    global gifts, gifts_error
    if gifts is not None:
        return True
    async with _gifts_lock:
        if gifts is not None:
            return True
        try:
            log.info("Загружаю TelegramGifts...")
            gifts = await asyncio.to_thread(_init_gifts)
            gifts_error = None
            log.info("TelegramGifts готов")
            return True
        except Exception as e:
            gifts_error = f"{type(e).__name__}: {e}"
            log.exception("Ошибка TelegramGifts")
            return False


async def fetch_gift(name: str):
    """get_gift синхронный (может ходить в сеть) — выносим из event loop."""
    return await asyncio.to_thread(gifts.get_gift, name)


def esc(value) -> str:
    return html.escape(str(value))


def get_arg(command: CommandObject) -> str:
    return (command.args or "").strip()


# ---------- Хендлеры ----------
@dp.message(Command("start", "help"))
async def cmd_start(message: types.Message):
    await message.answer(
        "Бот мониторинга NFT-подарков Telegram\n\n"
        "/price &lt;название&gt; — текущий floor\n"
        "/track &lt;название&gt; — добавить в отслеживание\n"
        "/list — список отслеживания\n"
        "/untrack &lt;название&gt; — убрать\n"
        "/ping — проверка"
    )


@dp.message(Command("ping"))
async def cmd_ping(message: types.Message):
    await message.answer("pong")


@dp.message(Command("price"))
async def cmd_price(message: types.Message, command: CommandObject):
    name = get_arg(command)
    if not name:
        await message.answer("Пример: /price Artisan Brick")
        return
    if not await ensure_gifts():
        await message.answer(f"Библиотека подарков не загрузилась:\n{esc(gifts_error)}")
        return
    try:
        info = await fetch_gift(name)
        if not info:
            await message.answer(f"Подарок «{esc(name)}» не найден")
            return
        prices = info.get("prices", {}) or {}
        await message.answer(
            f"<b>{esc(info.get('full_name', name))}</b>\n"
            f"Тип: {esc(info.get('type', '—'))}\n"
            f"Supply: {esc(info.get('supply', '—'))}\n\n"
            f"Floor (TGMrkt): {esc(prices.get('tgmrkt_price_ton', '—'))} TON\n"
            f"Portals: {esc(prices.get('portal_price_ton', '—'))} TON\n"
            f"GetGems: {esc(prices.get('getgems_price_ton', '—'))} TON"
        )
    except Exception as e:
        log.exception("price error")
        await message.answer(f"Ошибка: {esc(e)}")


@dp.message(Command("track"))
async def cmd_track(message: types.Message, command: CommandObject):
    name = get_arg(command)
    if not name:
        await message.answer("Пример: /track Plush Pepe")
        return
    uid = message.from_user.id
    items = tracked.setdefault(uid, [])
    if name.lower() in (n.lower() for n in items):
        await message.answer(f"«{esc(name)}» уже отслеживается")
        return
    items.append(name)
    save_tracked()
    await message.answer(f"Добавил «{esc(name)}» в отслеживание")


@dp.message(Command("untrack"))
async def cmd_untrack(message: types.Message, command: CommandObject):
    name = get_arg(command)
    uid = message.from_user.id
    if not tracked.get(uid):
        await message.answer("Список пуст")
        return
    if not name:
        await message.answer("Пример: /untrack Plush Pepe")
        return
    before = len(tracked[uid])
    tracked[uid] = [n for n in tracked[uid] if n.lower() != name.lower()]
    if len(tracked[uid]) == before:
        await message.answer(f"«{esc(name)}» в списке не найден")
        return
    save_tracked()
    await message.answer(f"Убрал «{esc(name)}»")


@dp.message(Command("list"))
async def cmd_list(message: types.Message):
    items = tracked.get(message.from_user.id, [])
    if not items:
        await message.answer("Список пуст. Добавь через /track")
        return
    await message.answer("Отслеживаю:\n" + "\n".join(f"• {esc(n)}" for n in items))


# ---------- Мониторинг цен ----------
async def monitor_loop():
    last_prices: dict[str, object] = {}  # name.lower() -> последняя цена
    while True:
        try:
            if tracked and await ensure_gifts():
                # собираем уникальные названия, чтобы не дёргать API по одному и тому же
                subscribers: dict[str, list[int]] = {}
                for uid, names in list(tracked.items()):
                    for n in names:
                        subscribers.setdefault(n.lower(), []).append(uid)

                for key, uids in subscribers.items():
                    try:
                        info = await fetch_gift(key)
                        if not info:
                            continue
                        price = (info.get("prices", {}) or {}).get("tgmrkt_price_ton")
                        if price is None:
                            continue
                        old = last_prices.get(key)
                        if old is not None and old != price:
                            text = (
                                "Цена изменилась!\n"
                                f"<b>{esc(info.get('full_name', key))}</b>\n"
                                f"Было: {esc(old)} → Стало: {esc(price)} TON"
                            )
                            for uid in uids:
                                try:
                                    await bot.send_message(uid, text)
                                except Exception:
                                    log.warning("Не отправил уведомление %s", uid)
                        last_prices[key] = price
                    except Exception:
                        log.exception("monitor: ошибка по подарку %s", key)
        except Exception:
            log.exception("monitor loop error")
        await asyncio.sleep(CHECK_INTERVAL)


# ---------- Health-check (только если хостинг задал PORT) ----------
async def start_health_server():
    if not PORT:
        return None
    from aiohttp import web

    async def ok(_request):
        return web.Response(text="ok")

    app = web.Application()
    app.add_routes([web.get("/", ok), web.get("/health", ok)])
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", int(PORT)).start()
    log.info("Health-check слушает порт %s", PORT)
    return runner


async def memory_loop():
    """Раз в минуту пишет в лог потребление памяти (для диагностики лимита 128 МБ)."""
    import resource

    while True:
        rss_mb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
        log.info("Память (пик): %.0f МБ", rss_mb)
        await asyncio.sleep(60)


async def wait_for_telegram():
    """Проверяем токен и доступ к api.telegram.org, не падая при сбое сети."""
    while True:
        try:
            me = await bot.get_me()
            log.info("Подключился к Telegram как @%s (id %s)", me.username, me.id)
            return
        except Exception as e:
            log.error("Нет связи с Telegram API: %s: %s. Повтор через 10 с", type(e).__name__, e)
            await asyncio.sleep(10)


async def main():
    load_tracked()
    runner = await start_health_server()
    tasks = [asyncio.create_task(monitor_loop()), asyncio.create_task(memory_loop())]
    monitor_task = asyncio.gather(*tasks)
    try:
        await wait_for_telegram()
        log.info("Запускаю polling...")
        await dp.start_polling(bot, skip_updates=True)
    finally:
        monitor_task.cancel()
        await bot.session.close()
        if runner:
            await runner.cleanup()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass
    except Exception:
        log.exception("КРИТИЧЕСКАЯ ОШИБКА")
        sys.exit(1)
